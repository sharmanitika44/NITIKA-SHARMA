%ROC for example 2
function [ P ] = exthreeIIpaperconvergence( e,N,M )
         E1=exthreeIIpapererror(e,N,M);
         E2=exthreeIIpapererror(e,2*N,2*M);
         P=log2(E1/E2);


end

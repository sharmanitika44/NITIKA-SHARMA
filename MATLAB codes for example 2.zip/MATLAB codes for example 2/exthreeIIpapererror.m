
%maximum absolute error for example 2
function [ E2 ] = exthreeIIpapererror( e,N,M )
             u1=exthreeIIpaper1(e,N,M);
             u2=exthreeIIpaper2(e,2*N,2*M);
             E=zeros(N+1,M+1);
             for n=1:M
                 for i=1:N
              E(i,n)=abs(u1(i,n)-u2((2*i-1),(2*n-1)));
                 end
             end
             E1=max(E);
             E2=max(E1);
             
end